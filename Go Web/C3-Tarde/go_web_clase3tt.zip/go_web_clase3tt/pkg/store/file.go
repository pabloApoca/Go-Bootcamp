package store

import (
	"encoding/json"
	"os"
)

//Se debe implementar la interface Store con los métodos Read y Write, ambos métodos reciben una interface y devolverán un error.

type Store interface {
	Read(data interface{}) error
	Write(data interface{}) error
}

// Se debe implementar una constante de tipo Type para definir el tipo de store que se utilizará, en este caso solo será
//por archivo (FileType).

type Type string

const (
	FileType Type = "file"
)

//Se debe implementar la función Factory que se encarga de generar la estructura que deseamos y recibe el tipo de store que
//queremos implementar y el nombre del archivo.
//Se declara la estructura FileStore con el campo que guarde el nombre del archivo.

func New(store Type, fileName string) Store {
	switch store {
	case FileType:
		return &FileStore{fileName}
	}
	return nil
}

type FileStore struct {
	FileName string
}

//Se utiliza para escribir datos de la estructura en el archivo. Simplemente recibe una interface y lo convertirá a una
// representación JSON en bytes para guardarlo en el archivo que especificamos al momento de instanciar la función Factory.
func (fs *FileStore) Write(data interface{}) error {
	fileData, err := json.MarshalIndent(data, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(fs.fileName, fileData, 0644)
}

//Sirve para leer el archivo y guardar su contenido empleando la interface que recibirá como parámetro.
func (fs *FileStore) Read(data interface{}) error {
	file, err := os.ReadFile(fs.FileName)
	if err != nil {
		return err
	}
	return json.Unmarshal(file, &data)
}
