package main

/*
Comenzamos con:
go mod init C2-Tarde
Para agregar  a nuestra carpeta mod

Para utilizar Gin se requiere la versión 1.13+ de Go, una vez instalada, utilizamos el siguiente
comando para instalar Gin:
go get -u github.com/gin-gonic/gin

Luego lo importamos  a nuestro código:
import "github.com/gin-gonic/gin"
*/
//	"github.com/pabloApoca/go_web_clase2/cmd/server\handler"

import (
	"github.com/gin-gonic/gin"
	"github.com/joho/godotenv"
	"github.com/pabloApoca/go_web_clase3tt/cmd/server/handler"
	"github.com/pabloApoca/go_web_clase3tt/internal/products"
	"github.com/pabloApoca/go_web_clase3tt/pkg/store"
)

//Instanciamos cada capa del dominio Productos y utilizaremos los métodos del controlador para cada endpoint
func main() {
	//Se debe implementar la carga del archivo .env al inicio de la función main, el método Load carga
	//el contenido (del archivo .env) en la variable de entorno.
	_ = godotenv.Load()

	//Instanciamos desde el Factory de store, indicando el tipo archivo (FileType) y donde deseamos guardar el json,
	//y le pasamos la base de datos al repositorio.
	db := store.New(store.FileType, "./products.json")
	//repo := products.NewRepository()
	repo := products.NewRepository(db)
	service := products.NewService(repo)

	p := handler.NewProduct(service)

	r := gin.Default()
	pr := r.Group("/products")
	pr.POST("/", p.Store())
	pr.GET("/", p.GetAll())
	//Dentro del main del programa se agrega el router correspondiente al método PUT
	pr.PUT("/:id", p.Update())

	pr.PATCH("/:id", p.UpdateName())

	pr.DELETE("/:id", p.Delete())

	r.Run()

}

//Lo corremos con go run cmd/server/main.go

//Implementar godotenv al proyecto para poder acceder al archivo .env que se utilizará al correr el programa de manera local.
//go get -u github.com/joho/godotenv
