package products

//import repository
//import "github.com/pabloApoca/go_web_clase2/internal/products/repository.go"

//Implementaremos la interface Servicio con sus métodos y una función que reciba un Repositorio
//y nos devuelva el servicio que se utilizará, instanciado.
type Service interface {
	GetAll() ([]Product, error)
	Store(nombre, tipo string, cantidad int, precio float64) (Product, error)
	Update(id int, name, productType string, count int, price float64) (Product, error)
	UpdateName(id int, name string) (Product, error)
	Delete(id int) error
}
type service struct {
	repository Repository
}

func NewService(r Repository) Service {
	return &service{
		repository: r,
	}
}

//Implementaremos el método GetAll que se encargará de pasarle la tarea al Repositorio y nos retorna un array de Productos.
func (s *service) GetAll() ([]Product, error) {
	ps, err := s.repository.GetAll()
	if err != nil {
		return nil, err
	}

	return ps, nil
}

//El método Store se encargará de pasarle la tarea de obtener el ultimo ID y guardar el producto al Repositorio, el servicio se encargará de incrementar el ID.
func (s *service) Store(nombre, tipo string, cantidad int, precio float64) (Product, error) {
	lastID, err := s.repository.LastID()
	if err != nil {
		return Product{}, err
	}

	lastID++

	producto, err := s.repository.Store(lastID, nombre, tipo, cantidad, precio)
	if err != nil {
		return Product{}, err
	}

	return producto, nil
}

//Dentro del servicio se llama al repositorio para que proceda a actualizar el producto.
func (s *service) Update(id int, name, productType string, count int, price float64) (Product, error) {

	return s.repository.Update(id, name, productType, count, price)
}

//Dentro del servicio se llama al repositorio para que proceda a actualizar el nombre del producto.
func (s *service) UpdateName(id int, name string) (Product, error) {

	return s.repository.UpdateName(id, name)
}

//Dentro del servicio se llama al repositorio para que proceda a eliminar el producto.
func (s *service) Delete(id int) error {
	return s.repository.Delete(id)
}
