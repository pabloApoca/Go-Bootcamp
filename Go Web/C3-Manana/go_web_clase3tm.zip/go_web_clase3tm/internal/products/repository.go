package products

import "fmt"

//Empezaremos con implementar el repositorio. Lo primero que haremos es declarar las entidades que
//utilizaremos: Producto, Productos y el ultimo ID almacenado.
type Product struct {
	ID    int     `json:"id"`
	Name  string  `json:"nombre"`
	Type  string  `json:"tipo"`
	Count int     `json:"cantidad"`
	Price float64 `json:"precio"`
}

var ps []Product
var lastID int

//Implementaremos la interface Repositorio con sus métodos y una función que nos devuelva el
//repositorio que se utilizará.
type Repository interface {
	GetAll() ([]Product, error)
	Store(id int, nombre, tipo string, cantidad int, precio float64) (Product, error)
	LastID() (int, error)
	Update(id int, name, productType string, count int, price float64) (Product, error)
	UpdateName(id int, name string) (Product, error)
	Delete(id int) error
}

type repository struct{} //f2

func NewRepository() Repository {
	return &repository{}
}

//Implementaremos los métodos:
//GetAll: Obtener todos los Productos.
//LastID: Obtener el ultimo ID almacenado.

func (r *repository) GetAll() ([]Product, error) {
	return ps, nil
}

func (r *repository) LastID() (int, error) {
	return lastID, nil
}

//Implementaremos los métodos:
//Store: Guardará la información de producto, asignará el último ID a la variable y nos retorna la entidad Producto.
func (r *repository) Store(id int, nombre, tipo string, cantidad int, precio float64) (Product, error) {
	p := Product{id, nombre, tipo, cantidad, precio}
	ps = append(ps, p)
	lastID = p.ID
	return p, nil
}

//Se implementa la funcionalidad para actualizar el producto en memoria, en caso que coincida con el ID enviado,
//caso contrario retorna un error.
func (r *repository) Update(id int, name, productType string, count int, price float64) (Product, error) {
	p := Product{Name: name, Type: productType, Count: count, Price: price}
	updated := false
	for i := range ps {
		if ps[i].ID == id {
			p.ID = id
			ps[i] = p
			updated = true
		}
	}
	if !updated {
		return Product{}, fmt.Errorf("Producto %d no encontrado", id)
	}
	return p, nil
}

//Se implementa la funcionalidad para actualizar el nombre del producto en memoria, en caso que
//coincida con el ID enviado, caso contrario retorna un error.
func (r *repository) UpdateName(id int, name string) (Product, error) {
	var p Product
	updated := false
	for i := range ps {
		if ps[i].ID == id {
			ps[i].Name = name
			updated = true
			p = ps[i]
		}
	}
	if !updated {
		return Product{}, fmt.Errorf("Producto %d no encontrado", id)
	}
	return p, nil
}

//Se implementa la funcionalidad para eliminar el producto en memoria, en caso que coincida con el ID enviado,
//caso contrario retorna un error
func (r *repository) Delete(id int) error {
	deleted := false
	var index int
	for i := range ps {
		if ps[i].ID == id {
			index = i
			deleted = true
		}
	}
	if !deleted {
		return fmt.Errorf("Producto %d no encontrado", id)
	}
	ps = append(ps[:index], ps[index+1:]...)
	return nil
}
